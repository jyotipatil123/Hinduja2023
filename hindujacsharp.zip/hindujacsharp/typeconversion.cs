using System;

namespace hindujanamespace2
{
    class myclass3
    {
        static void Main(string[] args)
        {
            // implicit conversion
           // int x=23423;
           // long var1=x;
           // System.Console.WriteLine(var1);

            long a=9829384922;
            System.Console.WriteLine(a);
           
            a=238492384929;
            System.Console.WriteLine(a);

           //explicit conversion 
             long var1=15788;
             int x=(int)var1;
             System.Console.WriteLine(x);

             
        }
    }
}
