using System;

class  b
{
    static void Main(string[] args)
    {
        // Example
      //  System.Console.WriteLine("Hello........."+args[0]);
      int num1= int.Parse(args[0]);
      int num2=int.Parse(args[1]);

      System.Console.WriteLine("Addition result is : "+(num1 +num2));
    }
}
