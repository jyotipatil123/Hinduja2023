// string demo
using System;

class myclass9
{
    static void Main(string[] args)
    {
        string s1;
        s1="india";
        
        string s2="AMERICA";
        System.Console.WriteLine(s1);
        System.Console.WriteLine(s2);

       System.Console.WriteLine("String in upper case : "+ s1.ToUpper());
       System.Console.WriteLine("String in lower case : "+s1.ToLower());

       if(string.Compare(s1,s2)==0)
             System.Console.WriteLine("string are equal");
       else
            System.Console.WriteLine("strings are not equal");

       System.Console.WriteLine("Concatenation of strings : "+ string.Concat(s1,s2));

        
    }
}

