using System;

class myclass1
{
    public void function1()
    {
         System.Console.WriteLine("myclass1--- function1() is invoked");
    }
}

class myclass2 : myclass1  //single level inheritance
{
    public void function2()
    {
         System.Console.WriteLine("myclass2--- function2() is invoked");
    }
}
class myclass3 //child class    // multi level inheritance
    : myclass2  //parent class
{
    public void function3()
    {
        System.Console.WriteLine("myclass3---function3() is invoked");
    }
}

class mainclass
{
    static void Main(string[] args)
    {
        /*    myclass1 obj= new myclass1();
            obj.function1();

            myclass2 obj1= new myclass2();
            obj1.function2();  */

            myclass2 obj1= new myclass2();
            obj1.function1();
            obj1.function2();

            myclass3 obj2= new myclass3();
            obj2.function1();
            obj2.function2();
            obj2.function3();

    }
}