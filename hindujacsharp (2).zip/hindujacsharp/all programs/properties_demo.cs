using System;
// properties in c#

class Employee
{
    public int id { get; set; }   // auto implemented properties / auto properties 
    public string name {get;set;}
    public string loc="Bangalore";  //local variable
    public string location 
    {
        get
        {
            return loc;
        }
    }  //read only

    int mbnum;
    public int mobileno 
    {
        set
        {
            mbnum=value;
        }
    } // write only

    string city="mysore";
    public string City
    {
        get
        {
            return city;
        }
        set
        {
            city=value;
        }
    }
}

class A
{
    static void Main(string[] args)
    {
      Employee e1= new Employee();
      e1.id=101;
      e1.name="asha";

      System.Console.WriteLine("employee id 1 "+e1.id);
      System.Console.WriteLine("employee name 1 "+e1.name);

      Employee e2= new Employee();
      e2.id=102;
      e2.name="akshara";

      System.Console.WriteLine("employee id 2 "+e2.id);
      System.Console.WriteLine("employee name 2 "+e2.name);

      // read only demo
     //  e1.location="Bangalore";       //wrong 
       System.Console.WriteLine("Employee location is : "+ e1.location);

      // write only demo
      e1.mobileno=78787;  // can not read
     // System.Console.WriteLine("Mobile number is : "+ e1.mobileno);  //wrong 

       System.Console.WriteLine(e1.City);
       e1.City="Delhi";
       System.Console.WriteLine(e1.City);
    }
}

