using System;

class myclass
{
    static void Main(string[] args)
    {
        // boxing 
        int ob= 10;

        object obj= ob;
        System.Console.WriteLine(obj);


        //unboxing 
        int x=(int) obj;
        System.Console.WriteLine(x);

    }
}