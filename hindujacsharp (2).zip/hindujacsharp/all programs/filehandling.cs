
using System;
using System.IO;

class mainclass
{
    static void Main(string[] args)
    {
        FileInfo f1= new FileInfo("C:\\demo\\a.txt");
        System.Console.WriteLine(f1.Name);
        System.Console.WriteLine(f1.Extension);
        System.Console.WriteLine(f1.FullName);
        System.Console.WriteLine(f1.CreationTime);
        System.Console.WriteLine(f1.Length);

   DirectoryInfo fi = new DirectoryInfo(@"c:\demo");  
   Console.WriteLine("Directory name is {0} ", fi.Name);  
   Console.WriteLine("Directory creation time is {0} ", fi.CreationTime.ToLongTimeString());  
   Console.WriteLine("Directory Lastaccesstime is {0} ", fi.LastAccessTime.ToLongDateString());  
   Console.WriteLine("Directory exist is: ", fi.Exists);  
   Console.WriteLine("Directory LastWriteTime is {0} ", fi.LastWriteTime);  
   Console.WriteLine("Directory root is {0} ", fi.Root);  

     DriveInfo[] drives = DriveInfo.GetDrives();
            foreach (DriveInfo drive in drives)
            {
                if (drive.IsReady)
                {
                    Console.WriteLine("Drive Name : " + drive.Name);
                    Console.WriteLine("Drive Volume name : " + drive.VolumeLabel);
                    Console.WriteLine("Drive Format : " + drive.DriveFormat);
                    Console.WriteLine("Drive Type : " + drive.DriveType);
                    Console.WriteLine("Drive root directory name : " + drive.RootDirectory);
                    Console.WriteLine("Drive free space: " + drive.AvailableFreeSpace);
                    Console.WriteLine("Total Free space on the drive : " + drive.TotalFreeSpace);
                    Console.WriteLine("Total disk size : " + drive.TotalSize);
                    Console.WriteLine();
                }
            }

              // Provide directory name with complete location.  
            DirectoryInfo directory = new DirectoryInfo(@"c:\demo");  
            try  
            {  
                // Check, directory exist or not.  
                if (directory.Exists)  
                {  
                    Console.WriteLine("Directory already exist.");  
                    return;  
                }  
                // Creating a new directory.  
                directory.Create();  
                Console.WriteLine("The directory is created successfully.");  
            }  
            catch (Exception e)  
            {  
                Console.WriteLine("Directory not created: {0}", e.ToString());  
            }  
        }  


         // path of the file that we want to create
        string pathName = @"C:\demo\a.txt";

        // Create() creates a file at pathName 
        FileStream fs = File.Create(pathName);

        // check if myFile.txt file is created at the specified path 
        if (File.Exists(pathName))
        {
            Console.WriteLine("File is created.");
        }
        else
        {
            Console.WriteLine("File is not created.");
        }
    }
}