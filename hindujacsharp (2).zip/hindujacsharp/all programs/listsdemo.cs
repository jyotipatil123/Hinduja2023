//lists in c#

using System;
using System.Collections.Generic;

class K
{
    static void Main(string[] args)
    {
        List<int> mylist= new List<int>();
        mylist.Add(10);
        mylist.Add(20);
        mylist.Add(30);
        
        System.Console.WriteLine("List items are : ");
        foreach(int i in mylist)
        {
            System.Console.WriteLine(i);
        }
          
        mylist.Remove(20);

        System.Console.WriteLine("List items are : ");
        foreach(int i in mylist)
        {
            System.Console.WriteLine(i);
        }

//============================================================================

// Create a list of parts.
        List<int> parts = new List<int>();

        // Add parts to the list.
         parts.Add(40);
        parts.Add(50);
        parts.Add(60);
        parts.Add(70);
        parts.Add(80);
        parts.Add(10);
        parts.Add(20);
        parts.Add(30);       
        parts.Add(90);

         parts.Sort();
         System.Console.WriteLine("Sort : ");
         foreach (int aPart in parts)
        {
            Console.WriteLine(aPart);
        }
       
        // Write out the parts in the list. This will call the overridden ToString method
        // in the Part class.
        Console.WriteLine();
        foreach (int aPart in parts)
        {
            Console.WriteLine(aPart);
        }
        parts.RemoveAt(7);
        System.Console.WriteLine("Remove At : ");
        foreach (int aPart in parts)
        {
            Console.WriteLine(aPart);
        }

        parts.RemoveRange(0,2);
        System.Console.WriteLine("Remove range : ");
         foreach (int aPart in parts)
        {
            Console.WriteLine(aPart);
        }

       

    }
}
