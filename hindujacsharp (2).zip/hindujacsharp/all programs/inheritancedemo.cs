using System;

class animal
{
   public void color()
   {
       System.Console.WriteLine("different colors are there for animals");
   }
}

class tiger : animal
{
    public void roar()
    {
        System.Console.WriteLine("tiger roars");
    }
}

class turtle : animal
{
   public void scroll()
   {
       System.Console.WriteLine("turtle scrolls");
   } 
}

class newclass
{
    static void Main(string[] args)
    {
        turtle t1= new turtle();
        t1.color();
        t1.scroll();

    }
}