// linear search


using System;

class myclass
{
static int LinearSearch(int[] numbers, int target)
{
    for (int i = 0; i < numbers.Length; i++)
    {
        if (numbers[i] == target)
        {
            return i;
        }
    }
    return -1;
}

public static int BinarySearch(int[] numbers, int key) 
{
   int min = 0;
   int max = numbers.Length - 1;

    while (min <=max)
    {
       int mid = (min + max) / 2;
       
       if (key == numbers[mid])
       {
            return ++mid;
       }
       else if (key < numbers[mid])
       {
           max = mid - 1;
       }
       else
       {
            min = mid + 1;
       }
   }
   return -1;
}
 
 static void Main(string[] args)
 {
    
int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

int index = LinearSearch(numbers, 523);

System.Console.WriteLine("LInear Search :");

Console.WriteLine("The number 5 is at index " + index);

System.Console.WriteLine("Binary search : ");

int index1=BinarySearch(numbers,8);

Console.WriteLine("The number 8 is at index " + index1);
}
}
