//abstract classes

using System;

abstract class vehicle
{
    public abstract void color();
    public void engine()  //non abstract method
    {
        System.Console.WriteLine("Engine make is : 2000");
    }
}

class car : vehicle
{
    public override void color()
    {
        System.Console.WriteLine("car color is green");
    }
}

class myclass
{
    static void Main(string[] args)
    {
        //wrong
        // vehicle v1= new vehicle();
        // v1.color();
       //  v1.engine();

             
    }
}