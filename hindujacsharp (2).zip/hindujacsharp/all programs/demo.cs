using System;

class mainclass{
    static void Main(string[] args)
    {
          int a, b, c;
          a=10;
          b=20;
          c=30;

          System.Console.WriteLine("Different numbers are : ");
          
          System.Console.WriteLine($"value of a is : {a}"+$"value of b is : {b}"+ $"value of c is : {c}");
         
          System.Console.WriteLine("Value of a is : "+a+"value of b is :
           "+b+"value of c is : "+c);

          System.Console.WriteLine("a ,b,c values are {0} {1}{2}",a,b,c);
          
 
    }
}