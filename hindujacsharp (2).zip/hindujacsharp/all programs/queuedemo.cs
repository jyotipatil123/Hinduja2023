using System;
using System.Collections;
using System.Collections.Generic;

namespace namespace9
{
    class india
    {
        static void Main(string[] args)
        {
             Queue q1= new Queue();
             q1.Enqueue(10);
             q1.Enqueue(12);
             q1.Enqueue(13);
             q1.Enqueue(14);
             q1.Enqueue(16);

             System.Console.WriteLine("Queue elements are : ");
             foreach(int i in q1)
             {
                System.Console.WriteLine(i);
             }
            System.Console.WriteLine("Queue count is : "+q1.Count);
           // q1.Clear();

            q1.Dequeue();
           System.Console.WriteLine("Queue elements after Dequeue  : ");
             foreach(int i in q1)
             {
                System.Console.WriteLine(i);
             }
            

        }
    }
}