using System;

namespace hindujanamespace
{
   public class myclass
   {
      static void Main()
      {
        //  Console.WriteLine("welcome to Hinduja Team");
          int a=10;
          char b='x';
          bool var1= true;
          string s1="hello";
          float c=3.21212f;
          double d=898989.28787;

         System.Console.WriteLine( a);
         System.Console.WriteLine( b);
         System.Console.WriteLine( var1);
         System.Console.WriteLine( s1);
         System.Console.WriteLine( c);   
         System.Console.WriteLine(d);       
          
          Console.Read();   // Console.ReadKey()  // Console.ReadLine()

      }
   }
}