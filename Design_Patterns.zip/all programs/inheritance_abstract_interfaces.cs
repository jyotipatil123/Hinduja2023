using System;

interface Iinterface1
{
   public void add();
}

interface Iinterface2 :Iinterface1
{
   public void multiply();
}

class derivedclass : Iinterface2
{
    public void add()
    {
        System.Console.WriteLine("Add() is invoked");
    }
     public void multiply()
     {
        System.Console.WriteLine("Multiply() is invoked");
     }
}

class myclass
{
    static void Main(string[] args)
    {
          derivedclass obj= new derivedclass();
          obj.add();
          obj.multiply();


    }
}