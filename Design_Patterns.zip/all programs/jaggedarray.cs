using System;

namespace a
{
    class myclass
    {
        static void Main(string[] args)
        {
            //First declare the jagged array

           string[][] str = new string[5][];  //declare

           str[0] = new string[5];

           str[1] = new string[10];

           str[2] = new string[20];

           str[3] = new string[50];

           str[4] = new string[10];

           //Now store data in the jagged array

           str[0][0] = "Pune";

           str[1][0] = "Kolkata";

           str[2][0] = "Bangalore";

           str[3][0] = "The pink city named Jaipur";

           str[4][0] = "Hyderabad";

            //Lastly, display the content of each of the string arrays inside the jagged array

           for (int i = 0; i < 5; i++)

               Console.WriteLine(str[i][0]);
        }
    }
}