// DateTime Demo

using System;

namespace P1
{
    class demo
    {
        static void Main(string[] args)
        {
            DateTime d1 = new DateTime(1974, 7, 10, 7, 10, 24);  
            Console.WriteLine("Day:{0}", d1.Day);  
            Console.WriteLine("Month:{0}", d1.Month);  
            Console.WriteLine("Year:{0}", d1.Year);  
            Console.WriteLine("Hour:{0}", d1.Hour);  
            Console.WriteLine("Minute:{0}", d1.Minute);  
            Console.WriteLine("Second:{0}", d1.Second);  
            Console.WriteLine("Millisecond:{0}", d1.Millisecond);  
  
            Console.WriteLine("Day of Week:{0}", d1.DayOfWeek);  
            Console.WriteLine("Day of Year: {0}", d1.DayOfYear);  
            Console.WriteLine("Time of Day:{0}", d1.TimeOfDay);  
            Console.WriteLine("Tick:{0}", d1.Ticks);  
            Console.WriteLine("Kind:{0}", d1.Kind);  

            DateTime d2 = new DateTime(1974, 7, 10, 7, 10, 24);           
            DateTime d3 = new DateTime(1972, 7, 10, 7, 8,10, 24);  
           
            TimeSpan timediff= d3-d2;
            System.Console.WriteLine("Time difference is : {0}",timediff.ToString());
//==============================================================================

DateTime launchDate = new DateTime(2020, 3, 15, 9, 0, 0);
DateTime now = DateTime.Now;

// Calculate the interval between the two dates.
TimeSpan ts = launchDate - now;

Console.WriteLine("TimeSpan: {0}", ts.ToString());

// TimeSpan properties
Console.WriteLine("Days: {0}", ts.Days);
Console.WriteLine("Total Number of Days: {0}", ts.TotalDays);
Console.WriteLine("Hours: {0}", ts.Hours);
Console.WriteLine("Total number of hours: {0}", ts.TotalHours);
Console.WriteLine("Minutes: {0}", ts.Minutes);
Console.WriteLine("Total Number of Minutes: {0}", ts.TotalMinutes);
Console.WriteLine("Seconds: {0}", ts.Seconds);
Console.WriteLine("Total Number of Seconds: {0}", ts.TotalSeconds);
Console.WriteLine("Milliseconds: {0}", ts.Milliseconds);
Console.WriteLine("Total Number of Milliseconds: {0}", ts.TotalMilliseconds);
Console.WriteLine("Ticks: {0}", ts.Ticks);
        }
    }
}