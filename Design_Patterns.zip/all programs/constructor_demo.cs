// constructors and constructor types 
// types :
//1. static constructor
//2. private constructor
//3. parameterized constructor
//4. default constructor
//5. copy constructor

using System;

class car
{
    public car()  //default constructor 
    {
        System.Console.WriteLine("Car constructor is invoked ");
    }
    public car(string color )  //parameterized constructor 
    {
        System.Console.WriteLine("Car color is :"+color);
    }
}

class  vehicle
{
    static void Main(string[] args)
    {
         car obj= new car();   // used to invoke default constructor

         car obj1= new car("red");  // used to invoked parameterized constructor

    }
} 