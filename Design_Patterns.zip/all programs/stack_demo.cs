//stack demo

using System;
using System.Collections;


class myclass123
{
    public static void Main(string[] args)
    {
        Stack s1= new Stack();
        s1.Push(10);
        s1.Push(11);
        s1.Push(12);
        s1.Push(13);

        System.Console.WriteLine("List of items in stack are : ");
        foreach(int i in s1)
        {
            System.Console.WriteLine(i);
        }

        s1.Pop();
         System.Console.WriteLine("List of items in stack after pop are : ");
        foreach(int i in s1)
        {
            System.Console.WriteLine(i);
        }

        System.Console.WriteLine("stack count is : "+s1.Count);

        s1.Clear();
        
    }
}


