//interfaces in c#

//contracts 

using System;

interface myinterface1
{
   public void function1();  
}

interface myinterface2
{
    public void function2();
}

class india : myinterface1, myinterface2
{
      public void function1()
      {
        System.Console.WriteLine("Hello from function1()");
      }
     public void function2()
      {
        System.Console.WriteLine("Hello from function2()");
      }
}

class myclass
{
    static void Main(string[] args)
    {
        india i1= new india();
        i1.function1();
        i1.function2();

        myinterface1 obj1= new  myinterface1();
        myinterface2 obj2= new myinterface2(); 

    }
}